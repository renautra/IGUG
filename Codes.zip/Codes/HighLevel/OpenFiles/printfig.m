function printfig(filename) 
% Short function to simplify generating figures
% can be edited to pick the file type
% The main point is to do regexprep on filename
filename=regexprep(filename,'\.','');
h=gcf;
set(gcf,'PaperPositionMode','auto')
print(h,'-djpeg',[filename,'.jpg'])


