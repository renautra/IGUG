%function [datafit1,datafit2,datafit3,res1,res2,res3,yhat1,yhat2,yhat3]=...
%    Regression_Analysis(Gamma, Theta,Phi,k,startk)
% Input: 
% Gamma : BestFit(1:k-1)
% Theta : BestTeta(1:k-1)
% Phi   : BestMisfit(1:k-1)
% Regression on data from startk=75 to  final k
% if k<74, startk=floor(k/2)
% This is used to do a regression analysis for the functions $\Gamma$, $\Theta$, and $\Phi$
% For  $\Theta$ the linear regression is based on a $\log(\Theta)$. The function also calculates the R2 coefficient
% Output 
% datafit*(1) -intersept
% datafit*(2) -slope
% res*        -R2 - coefficient of determination
% yhat*       -the predicted data from the fitting
% September 16, 2018. Rosemary Renaut

function [datafit1,datafit2,datafit3,res1,res2,res3,yhat1,yhat2,yhat3]=...
    Regression_Analysis(Gamma, Theta, Phi,k,startk)
[yhat1,datafit1(1),datafit1(2),res1]=datafit_linear((startk:k-1),log(Theta(startk:k-1)));
[yhat2,datafit2(1),datafit2(2),res2]=datafit_linear((startk:k-1),Phi(startk:k-1));
[yhat3,datafit3(1),datafit3(2),res3]=datafit_linear((startk:k-1),log(Gamma(startk:k-1)));
    