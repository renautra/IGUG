%% Diagnostic Results
% This is a script to show the results of a run for IGUG
% It is called directly from IGUG but if you wish to run with given results
% you can upload a .mat file of data
% To upload data comment out and give the filename for results generated from IGUG
% load(Resultsfilename); filename_results=Resultsfilename;
% September 16, 2018, Rosemary Renaut
% February 21, 2018, Rosemary Renaut
% Modification - updated to do exponential data fitting for Gamma 
% 
%
%% Should the results be saved as figures and spreadsheet with data fitting
button = questdlg('Do you want to do linear regression analysis for diagnostics?','Diagnostics','Yes','No','Yes');
datafit=0;savefigs=0;spreadsheet=0;
if (exist('EData','var') | (~isempty('EData'))) realdata=0; else realdata=1;end
switch button, case "Yes", datafit=1;end
%%
%
% <<QuestionDataFit.png>>
%
%%
button = questdlg('Do you want to save figures','Diagnostics','Yes','No','Yes');
switch button, case "Yes", savefigs=1;end
%%
%
% <<QuestionFigures.png>>
%
%%
button = questdlg('Do you want to save results to spreadsheet','Diagnostics','Yes','No','Yes');
switch button, case "Yes", spreadsheet=1;end
%%
%
% <<QuestionSpreadsheet.png>>
%
%%
%% Plot the results and do datafitting if requested
BestTetaEnd=[];BestMisfitEnd=[];BestFitEnd=[];startk=1;
ll=length(lambdai);
if (ll <= 4 ), px=1;py=ll; elseif ( ll==5 |  ll==6), px=3;py=2; elseif (ll <=9), px=3;py=3; else px=4;py=3;end
for ii=1:length(lambdai)
    % Info for the table
    BestTetaEnd=[BestTetaEnd;BestTetaAll(ii,count(ii))];
    BestMisfitEnd=[BestMisfitEnd;BestMisfitAll(ii,count(ii))];
    BestFitEnd=[BestFitEnd;BestFitAll(ii,count(ii))];
    k=count(ii)+1;
    % End of info for the table
    if datafit
        startk=min(75,floor((count(ii)+1)/2));
        [datafit1(:,ii),datafit2(:,ii),datafit3(:,ii),res1(ii),res2(ii),res3(ii),yhat1,yhat2,yhat3]=...
            Regression_Analysis(BestFitAll(ii,1:k-1),BestTetaAll(ii,1:k-1),BestMisfitAll(ii,1:k-1),k,startk);
        figure(4),subplot(px,py,ii), plot(1:k-1,log(BestTetaAll(ii,1:k-1)),'--kd',startk:k-1,yhat1,'*b','LineWidth',0.5);
        legend('Results','DataFit');title(['\lambda = ',num2str(lambdai(ii)),' R2 = ',num2str(res1(ii))]);
        figure(5),subplot(px,py,ii), plot(1:k-1,BestMisfitAll(ii,1:k-1),'--kd',startk:k-1,yhat2,'*b','LineWidth',0.5);
        legend('Results','DataFit');title(['\lambda = ',num2str(lambdai(ii)),' R2 = ',num2str(res2(ii))])
        figure(6),subplot(px,py,ii), plot(1:k-1,log(BestFitAll(ii,1:k-1)),'--kd',startk:k-1,(yhat3),'*b','LineWidth',0.5);
        legend('Results','DataFit');title(['\lambda = ',num2str(lambdai(ii)),' R2 = ',num2str(res3(ii))])
        figure(7),subplot(px,py,ii),contourf(Estat,Nstat,(reshape(gz(ii,:),nse,nsn))');shading flat;
        title(['\lambda = ',num2str(lambdai(ii))]);
    else
        figure(4),subplot(px,py,ii), plot(1:k-1,log(BestTetaAll(ii,1:k-1)),'LineWidth',0.5);
        legend('Results' );title(['\lambda = ',num2str(lambdai(ii))]);
        figure(5),subplot(px,py,ii), plot(1:k-1,BestMisfitAll(ii,1:k-1),'LineWidth',0.5);
        legend('Results' );title(['\lambda = ',num2str(lambdai(ii))])
        figure(6),subplot(px,py,ii), plot(1:k-1,log(BestFitAll(ii,1:k-1)),'LineWidth',0.5);
        legend('Results' );title(['\lambda = ',num2str(lambdai(ii))])
        figure(7),subplot(px,py,ii),contourf(Estat,Nstat,(reshape(gz(ii,:),nse,nsn))');shading flat;
        title(['\lambda = ',num2str(lambdai(ii))]);
    end
end
figure(4),suptitle(['\fontsize{16} \bf \Theta(p)']);set(gcf,'Units','Centimeter','Position',[1 5 25 25]);
figure(5),suptitle(['\fontsize{16} \bf \Phi(p)']);set(gcf,'Units','Centimeter','Position',[26 5 25 25]);
figure(6),suptitle(['\fontsize{16} \bf \Gamma(p)']);set(gcf,'Units','Centimeter','Position',[51 5 25 25]);
figure(7),suptitle(['\fontsize{16} \bf Predicted Data']);set(gcf,'Units','Centimeter','Position',[76 5 25 25]);
%% Plot the Mass Point Distribution
figure(3),clf
for ii=1:length(lambdai)
    subplot(px,py,ii),
    PlotDomainStructure(Fac,Ver,East1,East2,North1,North2,Depth1,Depth2,prismdef,noc)
    ScatterPlotResults(FpAll(ii,:),M);
    if datafit
        title(['\lambda = ',num2str(lambdai(ii)),' R2 = ',num2str(res1(ii))])
    else
        title(['\lambda = ',num2str(lambdai(ii))])
    end
end
set(gcf,'Units','Centimeter','Position', [3 1 30 30]);
%% If figures should be saved then do printfig on each
if ~exist('filename_results')| (isempty('filename_results'))
    if realdata
        filename_results = ['ResultsRealM',int2str(M)];
    else
        filename_results = ['ResultsDataM',int2str(M)];
    end
end
if savefigs
    for i=3:6
        figure(i)
        printfig(['Figure',int2str(i),filename_results]);
    end
    if (exist('EData') && (~isempty('EData')))
        figure(7), printfig(['Figure',int2str(7),filename_results]);end
end
%% Show the results as a table dependent on whether datafit has been done
mm=N+sqrt(2*N);
if datafit
    T=table(mass(:),count(:),BestTetaEnd,BestMisfitEnd/mm,BestFitEnd,lambdai(:),datafit1',res1(:),datafit2',res2(:),datafit3',res3(:),...
        'VariableNames',{'mass','kend','Theta','Phi_over_chi','Gamma','lambda',...
        'logdatafitTheta','r2theta','lindatafitPhi','r2Phi','lindatafitGamma','r2Gamma'})
else
    T=table(mass(:),count(:),BestTetaEnd,BestMisfitEnd/mm,BestFitEnd,lambdai(:),...
        'VariableNames',{'mass','kend','Theta','Phi_over_chi','Gamma','lambda'})
end
if spreadsheet
    writetable(T,['Table',filename_results,'.xls']);
end

