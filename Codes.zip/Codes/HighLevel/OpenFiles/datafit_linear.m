function [predictedy, intersept, slope, rsquared]=datafit_linear(xdata, ydata)
%% This code does a linear data fit 
% Input data
% xdata - length n
% ydata - length n
% Output data
% predictedy - length n
% intersept - scalar
% slope - scalar
% rsquared - scalar coefficient of determination
% The variables are determined as the minimum of $F(a,b)$ where $a$ is
% slope, $b$ is intersept $(x_i,y_i)=(xdata(i),ydata(i))$. 
% Then 
%
% $$F(a,b)=\sum_{i=1}^n (y_i - (a  x_i +b)^2,$$   
% $$\frac{\partial F}{\partial a} = 0 = \sum_{i=1}^n (y_ix_i -ax_i^2-bx_i)$$ 
% $$\frac{\partial F}{\partial b} = 0 = \sum_{i=1}^n (y_i-ax_i -b ).$$ 
%
% Let
% $\mu (x) = mean(x)$, $\mu (y) = mean(y)$, $\mu (yx) = mean(yx)$ and $\mu (x^2) = mean(x^2)$.
% Then 
% 
% $$a= \frac{\mu(xy) -\mu(x)\mu (y)}{\mu(x^2)-\mu^2(x)}, \,\, b=\mu(y)-a\mu(x)$$
% 
% and with predictedy denoted by $\hat{y}$
% 
% $$R2 =  \left(\frac{\sum_{i=1}^n ( \hat{y}_i  - \mu(y))}{\sum_{i=1}^n (y_i  - \mu(y))}\right)^2 $$
% 
% is the  rsquared value. 
%
% September 18 2018. Rosemary Renaut

%%
n=length(ydata);
if length(ydata)~=length(xdata) 
    display('data lengths not the same')
else
    ymean=mean(ydata);
    xmean=mean(xdata);
    xmean2=mean(xdata.*xdata);
    xymean=mean(xdata(:).*ydata(:));
    slope=(xymean  -xmean*ymean )/(xmean2-xmean^2);
    intersept=ymean-xmean *slope;
    predictedy=slope*xdata(:)+intersept;
    rsquared=(norm(predictedy-ymean*ones(size(ymean)))/norm(ydata-ymean*ones(size(ymean))))^2;
end
    
    
