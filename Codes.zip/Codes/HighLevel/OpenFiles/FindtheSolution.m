%% FindtheSolution
% Script to minimize the function Gamma using the Method described in IGUG paper
% The script assumes that the domain has been set up
% That the data has been provided
% That all parameters of the method have been provided
% The code returns a vector for each function at population
% $q(k)=[m(k),p(k)]$ for covariance $W_d$, $M$ point masses total weight $m$
%
%   BestFit -  Gamma - 
%
% $$\Gamma(q)=\Phi(q)+\lambda \Theta(p)$$
%
%   BestTeta - Theta - Equidistance Function 
%
% $$\Theta(p)=\sum_{i=1}^M\|d_i^{MST}(p)-d_{mean}^{MST}\|^2$$
%
%   BestMisfit - Phi -Data Misfit 
%
% $$\Phi(q)=\|W_d(gobs - gz(q))\|^2_2$$
%   
%%
%% Generate Initial population
[InitPop] = InitialPopulation(PopSize,MinVal,MaxVal,M); % Should be selected randomely in search limits.
%% Generate equidistance function (for initial population)
[Teta]=Equidistance(M,InitPop(:, 2:end),PopSize); % Equidistance functions for all individuals.
%% Compute the fitness (for initial population)
[Gamma,DataMisfit]=Fitness(dobs,lambda,Wd,Teta,M,InitPop,Estat,Nstat,Astat,nse,nsn,N,PopSize);
%% Initialization
Empty_individual.Para=[]; Empty_individual.Fit=[]; Empty_individual.Teta=[]; Empty_individual.Mis=[];
Pop=repmat(Empty_individual,PopSize,1);
for i=1:PopSize
    Pop(i).Para=InitPop(i,:);
    Pop(i).Fit=Gamma(i,1);
    Pop(i).Teta=Teta(i,1);
    Pop(i).Mis=DataMisfit(i,1);
end
%............................ Sort population ............................
Fit=[Pop.Fit];
[Fit,Order]=sort(Fit);
Pop=Pop(Order); % Sorted population
%........................... Store the best solution .....................
BestSol=Pop(1);
%......................... Arrays to hold best values ....................
BestFit=zeros(GenNum,1);
BestTeta=zeros(GenNum,1);
BestMisfit=zeros(GenNum,1);
%........................... Store the worst fitness .....................
WFit=Pop(end).Fit;
BestMisfit=zeros(GenNum,1);
%........................... Store the worst fitness .....................
WFit=Pop(end).Fit;
%% Start the main loop
k=1;
BestSol.Mis=10^6;
while ((BestSol.Mis >  N+sqrt(2*N)) && (k-1<GenNum))
    % .....................Calculate selection probability..................
    P=exp(-Beta*Fit/WFit);
    P=P/sum(P);
    % ............................Crossover................................
    PopC=repmat(Empty_individual,NC/2,2);
    for j=1:NC/2
        % .......................Select parents indices.........................
        pi1=RWSelection(P); % Roulette Wheel Selection
        pi2=RWSelection(P);
        % ........................Select parents................................
        pa1=Pop(pi1);
        pa2=Pop(pi2);
        % ........................Apply crossover...............................
        [PopC(j,1).Para, PopC(j,2).Para]=Crossover(pa1.Para,pa2.Para,Errf,MinVal,MaxVal);
        %....................... Evaluate offsprings...........................
        [PopC(j,1).Teta]=Equidistance(M,PopC(j,1).Para(:, 2:end),1);
        [PopC(j,1).Fit,PopC(j,1).Mis]=Fitness(dobs,lambda,Wd,PopC(j,1).Teta,M,PopC(j,1).Para,Estat,Nstat,Astat,nse,nsn,N,1);
        [PopC(j,2).Teta]=Equidistance(M,PopC(j,2).Para(:, 2:end),1);
        [PopC(j,2).Fit,PopC(j,2).Mis]=Fitness(dobs,lambda,Wd,PopC(j,2).Teta,M,PopC(j,2).Para,Estat,Nstat,Astat,nse,nsn,N,1);
    end
    PopC=PopC(:);
    % ............................ Mutation................................
    PopM=repmat(Empty_individual,NM,1);
    for j=1:NM
        % ........................... Select parent.............................
        i=randi([1 PopSize]);
        pa=Pop(i);
        % ............................Apply mutation............................
        PopM(j).Para=Mutate(pa.Para,Mu,MinVal,MaxVal);
        % ............................Evaluate mutant...........................
        [PopM(j).Teta]=Equidistance(M,PopM(j).Para(:, 2:end),1);
        [PopM(j).Fit,PopM(j).Mis]=Fitness(dobs,lambda,Wd,PopM(j).Teta,M,PopM(j).Para,Estat,Nstat,Astat,nse,nsn,N,1);
    end
    % .......................Create merged population......................
    Pop=[Pop;  PopC;  PopM]; %#ok
    % ............................Sort population...........................
    Fit=[Pop.Fit];
    [Fit,Order]=sort(Fit);
    Pop=Pop(Order);
    % ............................Update worst cost.........................
    WFit=max(WFit,Pop(end).Fit);
    % ..............................Truncation..............................
    Pop=Pop(1:PopSize);
    Fit=Fit(1:PopSize);
    % ......................Store best solution ever found..................
    BestSol=Pop(1);
    % ...................... Store best values ever found...................
    BestFit(k)=BestSol.Fit;
    BestTeta(k)=BestSol.Teta;
    BestMisfit(k)=BestSol.Mis;
    k=k+1;
end % End of the iteration
