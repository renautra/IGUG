function PlotDomainStructure(Fac,Ver,East1,East2,North1,North2,Depth1,Depth2,prismdef,noc)
% Produce the domain and the structure if noc is specified
% The function needs the faces to show and vertices
% For simulated data this is known from the Data File
% leave noc and prismdef empty if not known
patch('Faces',Fac,'Vertices',Ver,'FaceColor','w');  % patch function
axis([East1, East2, North1, North2, Depth1, Depth2]);
axis equal;
set(gca,'ZDir','reverse')
set(gcf,'PaperPositionMode','auto')
set(gca,'FontSize',12,'linewidth',1.5);
set(gcf,'Units','Centimeter','Position', [3 1 30 30]);
view(-52,18);
hold on % now plot the dike if it is specified
if ~isempty(noc)
for i=1:noc
    East1C=str2num(cell2mat(prismdef{i}(1)));East2C=str2num(cell2mat(prismdef{i}(2)));
    North1C=str2num(cell2mat(prismdef{i}(3)));North2C=str2num(cell2mat(prismdef{i}(4)));
    Depth1C=str2num(cell2mat(prismdef{i}(5)));Depth2C=str2num(cell2mat(prismdef{i}(6)));
    VerC = [East1C North1C Depth1C;East2C North1C Depth1C;East1C North2C Depth1C;   ...
            East2C North2C Depth1C;East1C North1C Depth2C;East2C North1C Depth2C;   ...
            East1C North2C Depth2C;East2C North2C Depth2C];
    patch('Faces',Fac,'Vertices',VerC,'FaceColor','w','linewidth',1.5);
    hold on
end
material metal;
alpha('color');
alphamap('rampdown');
end