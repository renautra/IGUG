function PlotObsData(d,nse,nsn,Estat,Nstat)
% Plot the observed data d or prediction of data, gz, from estimates
% It should be assumed that the user can provide data and 
% coordinates
contourf(Estat,Nstat,(reshape(d,nse,nsn))');shading flat;
h=colorbar;axis tight;
title(h,'mGal','FontName','Times New Roman','FontSize',13)
title('Observed Data','FontName','Times','FontSize',15);

