%% GMD: Generate a Model and its Data
% For real data this program generates the data for use with IGUG. It is assumed that the user can provide parameters listed below
% 
% For simulated data the program generates a model using a set of prisms
% and computes the vertical component of gravity field with given noise
% level.
%% Input for real data (a data file) 
% * gse: Grid spacing in east direction.
% * gsn: Grid spacing in north direction.
% * nse: Number of stations in east direction.
% * nsn: Number of stations in north direction.
% * Estat: East-coordinate of stations.
% * Nstat: North-coordinate of stations
% * Astat: Depth-coordinate of the stations.
% * surveyvol: sizes in east, north and depth, with coordinate of the origin
% * Sd: Standard deviation of the noise. (for real data)
% * dobs : Measured data for real data. 
%% Inputs required for simulated data (or use defaults)
% * gse: Grid spacing in east direction.
% * gsn: Grid spacing in north direction.
% * nse: Number of stations in east direction.
% * nsn: Number of stations in north direction.
% * N: Total number of stations. 
% * Estat: East-coordinate of stations.
% * Nstat: North-coordinate of stations
% * surveyvol: sizes in east, north and depth, with coordinate of the origin
% * noc: Number of prisms which form the model.(for simulation)
% * prismdef: prism coordinates
% * noise: Noise level for the simulation. (for simulation)
%% Outputs to file for IGUG
% * gse: Grid spacing in east direction.
% * gsn: Grid spacing in north direction.
% * nse: Number of stations in east direction.
% * nsn: Number of stations in north direction.
% * N: Total number of stations.
% * Estat: East-coordinate of stations.
% * Nstat: North-coordinate of stations
% * Astat: Depth-coordinate of stations.
% * surveyvol coordinates: sizes in east, north and depth, with coordinate of the origin
% * noc: Number of prisms which form the model.(for simulation)
% * prismdef: prism coordinates (for simulation)
% * EData: Exact data of the model. (only for simulation)
% * NData: Noise added data. 
% * dobs: Noise added data. 
% * Sd: Standard deviation of the noise.  
%% Geometry
% Vertical component of the gravity field for the model.
%
%    ^ North
%    |
%    |
%    |
%    |-------------->  East
% Datafile that contains all parameters to run a simulation with this data.
%%
clc; clearvars; close all; % Make a clean environment
Gamma=6.673844e-8;   % Universal gravitational constant  (cm^3/gr.s^2)
Sd=[]; %Set empty. Overwritten if contained in RealData file 
surveyvol=[];
realbutton=questdlg('Are you using real data','Real Data','Yes','No','Yes');
%%
%
% <<RealDataQuestion.png>>
%
%%
switch realbutton
    case "Yes"
        filename_results=['AllRealData'];
        datafile={'DataReal'};
        prompt={'The datafile'};dialoguetitle='Please give the name of the local data file';
        datafile=inputdlg(prompt,dialoguetitle,[1, length(dialoguetitle)+20],datafile);
        %%
        %
        % <<RealDataFilename.png>>
        %
        load(string(datafile));
        if isempty(surveyvol)
            %%
            %
            % <<SurveyAreaQuestion.png>>
            %
            %%
            button = questdlg('Are you using the default survey area?','Survey area','Yes','No','Yes');
            surveyvol={'729.5030','607.8130','300','-0.0680','0.1356','0'};
            switch button
                case 'No'
                    prompt={'Size of the survey area in east direction (m)','Size of the area in north direction (m)',...
                        'Size of the area in depth direction (m) ',' East-coordinate of the origin ', ...
                        'North-coordinate of the origin ','Depth-coordinate of the origin '};
                    surveyvol=inputdlg(prompt,'Survey area',1,surveyvol);
                    %%
                    %
                    % <<SurveyAreaParameters.png>>
                    %
                    %%
            end
        end
        noc=[];prismdef=[];
        NData(:,1)=dobs;
        N=length(dobs);
        if isempty(Sd)%no noise information is provided
                tau={'.03','.004'};
                prompt={'what is t1=','what is t2='};
                querytitle='Noise dist:t1*abs(dobs)+t2*norm(dobs)';
                %%
                %
                % <<RealNoise.png>>
                %
                %%
                tau=inputdlg(prompt,querytitle',[1,length(querytitle)+30],tau);
                t1=str2num(cell2mat(tau(1)));t2=str2num(cell2mat(tau(2)));
                Sd=(t1.*abs(dobs)+(t2*norm(dobs))); % Approximate standard deviation for Mobrun's data. For each data set should be specified by user.
        end
        East2=str2num(cell2mat(surveyvol(1)));North2=str2num(cell2mat(surveyvol(2)));Depth2=str2num(cell2mat(surveyvol(3)));
        East1=str2num(cell2mat(surveyvol(4)));North1=str2num(cell2mat(surveyvol(5)));Depth1=str2num(cell2mat(surveyvol(6)));
        Ver=[East1 North1 Depth1;East2 North1 Depth1;East1 North2 Depth1;East2 North2 Depth1;...
            East1 North1 Depth2;East2 North1 Depth2;East1 North2 Depth2;East2 North2 Depth2];
        Fac=[1 2 4 3;1 2 6 5;1 3 7 5;3 4 8 7;2 4 8 6;5 6 8 7 ];
    case 'No'
        %% The Survey Volume (can be modified unless real data)
        button = questdlg('Are you using the default survey area?','Survey area','Yes','No','Yes');
        surveyvol={'2000','1500','1000','0','0','0'}; 
        %%
        %
        % <<SurveyAreaQuestion.png>>
        %
        %%
        switch button
            case 'No'
                prompt={'Size of the survey area in east direction (m)','Size of the area in north direction (m)',...
                    'Size of the area in depth direction (m) ',' East-coordinate of the origin ', ...
                    'North-coordinate of the origin ','Depth-coordinate of the origin '};
                surveyvol=inputdlg(prompt,'Survey area',1,surveyvol);
                %%
                %
                % <<SurveyAreaParameters.png>>
                %
                %%
        end
        East2=str2num(cell2mat(surveyvol(1)));North2=str2num(cell2mat(surveyvol(2)));Depth2=str2num(cell2mat(surveyvol(3)));
        East1=str2num(cell2mat(surveyvol(4)));North1=str2num(cell2mat(surveyvol(5)));Depth1=str2num(cell2mat(surveyvol(6)));
        Ver=[East1 North1 Depth1;East2 North1 Depth1;East1 North2 Depth1;East2 North2 Depth1;...
            East1 North1 Depth2;East2 North1 Depth2;East1 North2 Depth2;East2 North2 Depth2];
        Fac=[1 2 4 3;1 2 6 5;1 3 7 5;3 4 8 7;2 4 8 6;5 6 8 7 ];
        %% Other default data (can be modified unless real data)
        %%
        geometrydata={'3','50','50','2'};%Default number of prisms is 3 and default grid spacing 50 by 50. Noise level 2
        button = questdlg('Are you using the default discretization,  prisms, noise?','Discretization and noise','Yes','No','Yes');
        %%
        %
        % <<DiscretizationQuestion.png>>
        %
        %%
        switch button
            case 'No'
                prompt={'Number of prisms you want to put in the model',...
                    'Grid spacing in east direction (m) ','Grid spacing in north direction (m)',...
                    'Noise Level: tau1=[.03 .02 .01 .02];tau2=[.01 .005 .001 .001]'};
                geometrydata=inputdlg(prompt,'Structure and Noise',1,geometrydata);
                %%
                %
                % <<DiscretizationParameters.png>>
                %
                %%
        end
        noc=str2num(cell2mat(geometrydata(1)));
        gse=str2num(cell2mat(geometrydata(2)));
        gsn=str2num(cell2mat(geometrydata(3)));
        noise=str2num(cell2mat(geometrydata(4)));
        nse=round(East2/gse)+1; % Number of stations in East direction
        nsn=round(North2/gsn)+1; % Number of stations in North direction
        N=(nse*nsn); % Total number of stations
        Grav=zeros(N,noc); % Pre-allocate. Each column of Grav is gravity data generated by one cube.
        EData=zeros(N,1); %  EData is the sum of the exact gravity data of individual cubes.
        %% The Structure within the volume - here a dike that can be replaced unless real data
        %%
        prismdef{1}={'700','1300','800','1200','100','250','1'};%
        prismdef{2}={'700','1300','600','1000','250','400','1'};%
        prismdef{3}={'700','1300','400','800','400','550','1'};%
        button = questdlg('Are you using the default dike structure?','Structure Coordinates','Yes','No','Yes');
        %%
        %
        % <<StructureQuestion.png>>
        %
        %%
        switch button
            case 'No'
                for k=1:noc
                    prompt={'First East-coordinate of the prism (m)', 'Second East-coordinate of the prism (m)',...
                        'First North-coordinate of the prism (m)', 'Second North-coordinate of the prism (m)',...
                        'Top depth of the prism (m)','Base depth of the prism(m)', 'Density of the prism (gr/cm^3)'};
                    %              North2C |---------|
                    %    ^ North           |         |
                    %    |                 |         |
                    %    |         North1C |---------|
                    %    |               East1C      East2C
                    %    |
                    %    | ----------------------------------------->  East
                    if k>3 prismdef{k} = prismdef{1};end
                    prismdef{k}=inputdlg(prompt,'Prism Parameters',1,prismdef{k});
                end
                %%
                %
                % <<StructureParameters.png>>
                %
                %%
        end
        for k=1:noc
            East1C=str2num(cell2mat(prismdef{k}(1))); East2C=str2num(cell2mat(prismdef{k}(2)));
            North1C=str2num(cell2mat(prismdef{k}(3)));North2C=str2num(cell2mat(prismdef{k}(4)));
            Depth1C=str2num(cell2mat(prismdef{k}(5)));Depth2C=str2num(cell2mat(prismdef{k}(6)));
            Density=str2num(cell2mat(prismdef{k}(7)));
            %...........................................Compute gravity values on the grid...................
            Estat=East1:gse:((nse-1)*gse);     %  East-coordinate of stations
            Nstat=North1:gsn:((nsn-1)*gsn);    %  North-coordinate of stations
            v=1;
            for j=1:length(Nstat)
                for i=1:length(Estat)
                    g=OnePrismResponse(Nstat(j), Estat(i), North1C, North2C, East1C, East2C, Depth1C, Depth2C, Gamma, Density); % g is the gravitational attraction measured at one station
                    Grav(v,k)=g; % Gravitational attraction for all stations due to one cube.
                    v=v+1;
                    if v>N;  break; end
                end
            end
            EData=EData +Grav(:,k);
        end
        Astat=0; %  For synthetic examples, we suppose the elevation of stations are zero.
        %% Plot Exact Observed Gravity Data
        figure(2);clf, PlotObsData(EData,nse,nsn,Estat,Nstat)
        xlabel('Easting (m)','FontName','Times New Roman','FontSize',12);
        ylabel('Northing (m)','FontName','Times New Roman','FontSize',12);
        title('True Data','FontName','Times','FontSize',15);
        set(gcf,'Units','Centimeter', 'Position', [12 3 12  7.5]);
        %% Generate noisy data
        %%
        myseed=10;
        nnd=1; % Number of noisy data set user wants to generate
        e=randn(N,nnd);
        NData=zeros(N,nnd); %  NData is the noisy gravity data.
        % N3 (.03 .01), N2 (.02 .005) N1 (.01 .001) (Data in paper(.02 .002) )
        tau1=[.03 .02 .01 .02];tau2=[.01 .005 .001 .001];
        Sd=(tau1(noise).*EData+(tau2(noise)*norm(EData))); % Standard deviation of the noise. can be changed by user.
        for k=1:nnd
            NData(:,k) = EData+((Sd).*(e(:,k)));
        end
        clear e myseed nnd Grav g v Gamma button
        dobs=NData(:,1);
        filename_results=['DataN',int2str(noise)];
end
%% Plot the domain and the domain structure
figure(1),clf
PlotDomainStructure(Fac,Ver,East1,East2,North1,North2,Depth1,Depth2,prismdef,noc);
xlabel('Easting(m)','FontName','Times New Roman','FontSize',12);
ylabel('Northing(m)','FontName','Times New Roman','FontSize',12);
zlabel('Depth(m)','FontName','Times New Roman','FontSize',12);
set(gcf,'Units','Centimeter','Position', [2 3 12 7.5]);
%% Plot Noisy Observed Gravity Data
%%
figure(3);clf, PlotObsData(NData(:,1),nse,nsn,Estat,Nstat)
xlabel('Easting (m)','FontName','Times New Roman','FontSize',12);
ylabel('Northing (m)','FontName','Times New Roman','FontSize',12);
set(gcf,'Units','Centimeter', 'Position', [22 3 12  7.5]);
%% Save data
clear realbutton prompt dialoguetitle querytitle k tau t1 t2
Wd=diag(1./Sd);
save(filename_results)
%% Scripts and functions required. 
%
% <include>PlotDomainStructure.m</include>
%
% <include>PlotObsData.m</include>