%% OptimParameters 
% Script to collect the parameters used for the search algorithm
% September 16, 2018. Rosemary Renaut
%
%% Genetic algorithm parameters
prompt={'The size of population', 'The number of generation',...
    'Crossover percentage', ' Extra range factor for crossover',...
    'Mutation percentage','Mutation rate', 'Selection pressure','Number of Masses'};
button = questdlg('Would you like to run the genetic algorithm with defaults?','Genetic Algorithm Parameters','Yes','No','Yes');
%%
%
% <<QuestionGeneticParameters.png>>
%
%%
switch button
    case 'Yes'
        geneticparam={'100','200','0.7','0.4','0.3','0.1','8','20'};
        PopSize=str2num(cell2mat(geneticparam(1))); GenNum=str2num(cell2mat(geneticparam(2)));CP=str2num(cell2mat(geneticparam(3)));
        Errf=str2num(cell2mat(geneticparam(4)));MP=str2num(cell2mat(geneticparam(5)));Mu=str2num(cell2mat(geneticparam(6)));
        Beta=str2num(cell2mat(geneticparam(7)));M=str2num(cell2mat(geneticparam(8)));
        NC=2*round(CP*PopSize/2);  % Number of offsprings
        NM=round(MP*PopSize);      % Number of mutants
    case 'No'
        geneticparam={'100','200','0.7','0.4','0.3','0.1','8','20'};
        geneticparam=inputdlg(prompt,'Genetic algorithm parameters',[1,50],geneticparam);
        %%
        %
        % <<GeneticParameters.png>>
        %
        %%
        PopSize=str2num(cell2mat(geneticparam(1))); GenNum=str2num(cell2mat(geneticparam(2)));CP=str2num(cell2mat(geneticparam(3)));
        Errf=str2num(cell2mat(geneticparam(4)));MP=str2num(cell2mat(geneticparam(5)));Mu=str2num(cell2mat(geneticparam(6)));
        Beta=str2num(cell2mat(geneticparam(7)));M=str2num(cell2mat(geneticparam(8)));
        NC=2*round(CP*PopSize/2);  % Number of offsprings
        NM=round(MP*PopSize);      % Number of mutants
end
%% Specify the search limits
prompt={'Minimum of mt (kg)', 'Minimum in East direction (m)',...
    'Minimum in North direction (m)', ' Minimum in depth direction (m)',...
    'Maximum  of mt (kg)', 'Maximum in East direction (m)',...
    'Maximum in North direction (m)', ' Maximum in depth direction (m)'};
button = questdlg('Would you like to use default search limits?','Search Limits','Yes','No','Yes');
%%
%
% <<QuestionBounds.png>>
%
%%
searchlim={'70e9','400','100','20','150e9','1600','1400','1000'};
%realsearchlim={'2.2e9','150','50','10','3.2e9','650','500','300'}; used for the real data
switch button
    case 'Yes'
        MinValm=str2num(cell2mat(searchlim(1))); MinValE=str2num(cell2mat(searchlim(2))); MinValN=str2num(cell2mat(searchlim(3)));
        MinValD=str2num(cell2mat(searchlim(4))); MaxValm=str2num(cell2mat(searchlim(5))); MaxValE=str2num(cell2mat(searchlim(6)));
        MaxValN=str2num(cell2mat(searchlim(7))); MaxValD=str2num(cell2mat(searchlim(8)));
        MinVal=[MinValm,MinValE,MinValN,MinValD]; % The lower bounds of the variables.
        MaxVal=[MaxValm,MaxValE,MaxValN,MaxValD]; % The upper bounds of the variables.
        MinVal=[MinVal(1),repmat(MinVal(2:end), 1, M)];
        MaxVal=[MaxVal(1),repmat(MaxVal(2:end), 1, M)];
    case 'No'
        searchlim=inputdlg(prompt,'Search Limits',1,searchlim);
        %%
        %
        % <<SearchLimits.png>>
        %
        %%
        MinValm=str2num(cell2mat(searchlim(1))); MinValE=str2num(cell2mat(searchlim(2))); MinValN=str2num(cell2mat(searchlim(3)));
        MinValD=str2num(cell2mat(searchlim(4))); MaxValm=str2num(cell2mat(searchlim(5))); MaxValE=str2num(cell2mat(searchlim(6)));
        MaxValN=str2num(cell2mat(searchlim(7))); MaxValD=str2num(cell2mat(searchlim(8)));
        MinVal=[MinValm,MinValE,MinValN,MinValD]; % The lower bounds of the variables.
        MaxVal=[MaxValm,MaxValE,MaxValN,MaxValD]; % The upper bounds of the variables.
        MinVal=[MinVal(1),repmat(MinVal(2:end), 1, M)];
        MaxVal=[MaxVal(1),repmat(MaxVal(2:end), 1, M)];
end
%% Provide the lambda parameters no more than 12 or plotting is not good
button = questdlg('Would you like to pick lambda? Default is no with lambda=.2','lambda?','Yes','No','Yes');
%%
%
% <<QuestionLambda.png>>
%
%%
nlambda={'1'};
lambdavals={'100','10' ,'1','.5', '.25','.1','.05','.025','.01','.001','.0001','.00001'};%Use a range of regularization
switch button
    case "No"
        lambdai=.2;
    case "Yes"
        nlambda = inputdlg('How many lambda?','number',1,nlambda);
        %%
        %
        % <<NumberLambda.png>>
        %
        %%
        nlambda =str2num(cell2mat(nlambda));
        for ct=1:nlambda
            lambdavals(ct) = inputdlg('Another lambda','lambda',1,lambdavals(ct));
            %%
            %
            % <<AnotherLambda.png>>
            %
            %%
            lambdai(ct)=str2num(cell2mat(lambdavals(ct)));
        end
end
       
  

