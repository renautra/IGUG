function ScatterPlotResults(Fp,M)
% Produce scatter plot of the results 
x_j=Fp(1:3:3*M); y_j=Fp(2:3:3*M); z_j=Fp(3:3:3*M);
scatter3(x_j,y_j,z_j,'filled','k') 
material metal;
alpha('color');
alphamap('rampdown');
set(gcf,'Units','Centimeter', 'Position', [3 5 12 7.5]);
hold on
        